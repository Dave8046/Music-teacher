# Music Teacher Management System

## Overview

This is a full-stack music teacher management system built with React, Express, and PostgreSQL. The application helps music teachers manage their students, schedule lessons, track assignments, and monitor student progress. It features separate dashboards for teachers and students, with authentication and role-based access control.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (February 2, 2025)

✓ Fixed React hooks error in login component by moving navigation logic to useEffect
✓ Configured Express session middleware with proper TypeScript support  
✓ Resolved SQL date query issues in getTodaysLessons method
✓ Added proper error handling for authentication endpoints
✓ System now fully functional with real PostgreSQL database integration

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom piano-themed design tokens
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with role-based endpoints
- **Session Management**: Express sessions for authentication
- **Password Security**: bcrypt for password hashing
- **Validation**: Zod schemas for request/response validation

### Database Layer
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM for type-safe database queries
- **Schema Management**: Drizzle Kit for migrations
- **Connection**: Connection pooling with @neondatabase/serverless

### Authentication & Authorization
- **Strategy**: Session-based authentication with server-side session storage
- **Roles**: Teacher and Student roles with different access levels
- **Protected Routes**: Role-based route protection on both frontend and backend
- **Session Storage**: PostgreSQL session store using connect-pg-simple

### Data Models
- **Users**: Base user table with username, password, role, and profile information
- **Students**: Extended student information linked to users with teacher relationships
- **Lessons**: Scheduled lessons with status tracking and attendance records
- **Assignments**: Student assignments with due dates, completion status, and grading
- **Progress**: Student progress tracking and performance metrics

### File Structure
- **Monorepo Structure**: Client and server code in separate directories
- **Shared Code**: Common types and schemas in `/shared` directory
- **Component Organization**: UI components organized by type (pages, components, ui)
- **Type Safety**: Full TypeScript coverage across frontend, backend, and shared code

### Development Tools
- **Build System**: Vite for frontend bundling, esbuild for backend production builds
- **Development**: Hot module replacement and runtime error overlays
- **Code Quality**: TypeScript strict mode and comprehensive type checking
- **Path Aliases**: Configured import aliases for cleaner code organization

## External Dependencies

### Database Services
- **Neon Database**: PostgreSQL serverless database hosting
- **Connection Pooling**: WebSocket connections for serverless environments

### UI Libraries
- **Radix UI**: Headless UI primitives for accessible components
- **Lucide React**: Icon library for consistent iconography
- **React Hook Form**: Form management and validation
- **TanStack Query**: Server state management and caching

### Development Services
- **Replit Integration**: Development environment with cartographer plugin
- **Vite Plugins**: Runtime error modal and development tooling

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx & tailwind-merge**: Dynamic className composition
- **class-variance-authority**: Component variant management
- **zod**: Runtime type validation and schema definition