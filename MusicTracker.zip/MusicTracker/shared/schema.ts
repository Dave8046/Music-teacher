import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull(), // 'teacher' or 'student'
  name: text("name").notNull(),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const students = pgTable("students", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  teacherId: varchar("teacher_id").references(() => users.id).notNull(),
  instrument: text("instrument").notNull(),
  level: text("level").notNull(), // 'Principiante', 'Intermedio', 'Avanzado'
  schedule: text("schedule"), // JSON string with schedule info
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const lessons = pgTable("lessons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").references(() => students.id).notNull(),
  teacherId: varchar("teacher_id").references(() => users.id).notNull(),
  date: timestamp("date").notNull(),
  duration: integer("duration").notNull(), // minutes
  status: text("status").notNull().default('scheduled'), // 'scheduled', 'completed', 'cancelled'
  attendance: text("attendance"), // 'present', 'absent', 'late'
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const assignments = pgTable("assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").references(() => students.id).notNull(),
  teacherId: varchar("teacher_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: timestamp("due_date"),
  status: text("status").notNull().default('pending'), // 'pending', 'completed', 'overdue'
  grade: decimal("grade"),
  feedback: text("feedback"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const progress = pgTable("progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").references(() => students.id).notNull(),
  skill: text("skill").notNull(), // 'technique', 'rhythm', 'reading', etc.
  score: integer("score").notNull(), // 1-10 scale
  notes: text("notes"),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  studentsAsTeacher: many(students, { relationName: "teacher" }),
  studentsAsStudent: many(students, { relationName: "student" }),
  lessonsAsTeacher: many(lessons, { relationName: "teacherLessons" }),
  assignmentsAsTeacher: many(assignments, { relationName: "teacherAssignments" }),
}));

export const studentsRelations = relations(students, ({ one, many }) => ({
  user: one(users, {
    fields: [students.userId],
    references: [users.id],
    relationName: "student",
  }),
  teacher: one(users, {
    fields: [students.teacherId],
    references: [users.id],
    relationName: "teacher",
  }),
  lessons: many(lessons),
  assignments: many(assignments),
  progress: many(progress),
}));

export const lessonsRelations = relations(lessons, ({ one }) => ({
  student: one(students, {
    fields: [lessons.studentId],
    references: [students.id],
  }),
  teacher: one(users, {
    fields: [lessons.teacherId],
    references: [users.id],
    relationName: "teacherLessons",
  }),
}));

export const assignmentsRelations = relations(assignments, ({ one }) => ({
  student: one(students, {
    fields: [assignments.studentId],
    references: [students.id],
  }),
  teacher: one(users, {
    fields: [assignments.teacherId],
    references: [users.id],
    relationName: "teacherAssignments",
  }),
}));

export const progressRelations = relations(progress, ({ one }) => ({
  student: one(students, {
    fields: [progress.studentId],
    references: [students.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  createdAt: true,
});

export const insertLessonSchema = createInsertSchema(lessons).omit({
  id: true,
  createdAt: true,
});

export const insertAssignmentSchema = createInsertSchema(assignments).omit({
  id: true,
  createdAt: true,
});

export const insertProgressSchema = createInsertSchema(progress).omit({
  id: true,
  recordedAt: true,
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = z.infer<typeof insertLessonSchema>;
export type Assignment = typeof assignments.$inferSelect;
export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
export type Progress = typeof progress.$inferSelect;
export type InsertProgress = z.infer<typeof insertProgressSchema>;
export type LoginRequest = z.infer<typeof loginSchema>;
