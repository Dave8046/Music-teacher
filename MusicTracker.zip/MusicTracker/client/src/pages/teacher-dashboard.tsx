import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { PianoLogo } from "@/components/piano-logo";
import { useAuth, useLogout } from "@/lib/auth";
import { useLocation } from "wouter";
import { 
  Users, 
  CalendarCheck, 
  Music, 
  Trophy, 
  Plus, 
  Search, 
  Eye, 
  Clock, 
  CalendarPlus, 
  TrendingUp, 
  Bell, 
  Star,
  Piano
} from "lucide-react";

interface TeacherStats {
  totalStudents: number;
  todaysLessons: number;
  pendingAssignments: number;
  averageGrade: number;
}

interface StudentWithUser {
  id: string;
  instrument: string;
  level: string;
  schedule: string | null;
  notes: string | null;
  user: {
    id: string;
    name: string;
    username: string;
    email: string | null;
  };
}

interface TodaysLesson {
  id: string;
  date: Date;
  duration: number;
  status: string;
  student: StudentWithUser;
}

export default function TeacherDashboard() {
  const { data: authData, isLoading: authLoading } = useAuth();
  const logout = useLogout();
  const [location, setLocation] = useLocation();

  const { data: stats } = useQuery<TeacherStats>({
    queryKey: ["/api/teacher/stats"],
    enabled: !!authData?.user && authData.user.role === 'teacher',
  });

  const { data: students } = useQuery<StudentWithUser[]>({
    queryKey: ["/api/students"],
    enabled: !!authData?.user && authData.user.role === 'teacher',
  });

  const { data: todaysLessons } = useQuery<TodaysLesson[]>({
    queryKey: ["/api/lessons/today"],
    enabled: !!authData?.user && authData.user.role === 'teacher',
  });

  if (authLoading) {
    return <div className="min-h-screen bg-piano-gray-50 flex items-center justify-center">
      <div className="text-piano-gray-500">Cargando...</div>
    </div>;
  }

  if (!authData?.user || authData.user.role !== 'teacher') {
    setLocation('/login');
    return null;
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(word => word[0]).join('').toUpperCase().slice(0, 2);
  };

  const getProgressWidth = (level: string) => {
    switch (level) {
      case 'Principiante': return 'w-1/2';
      case 'Intermedio': return 'w-3/4';
      case 'Avanzado': return 'w-5/6';
      default: return 'w-1/3';
    }
  };

  const getAvatarColor = (index: number) => {
    const colors = [
      'bg-gradient-to-br from-gold-400 to-gold-600',
      'bg-gradient-to-br from-blue-400 to-blue-600',
      'bg-gradient-to-br from-purple-400 to-purple-600',
      'bg-gradient-to-br from-green-400 to-green-600',
      'bg-gradient-to-br from-red-400 to-red-600',
    ];
    return colors[index % colors.length];
  };

  return (
    <div className="min-h-screen bg-piano-gray-50 font-sans">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-piano-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <PianoLogo />
              <div>
                <h1 className="text-xl font-serif font-semibold text-piano-black">Music Teacher</h1>
                <p className="text-xs text-piano-gray-500">Panel del Profesor</p>
              </div>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-piano-black hover:text-gold-500 font-medium transition-colors">
                <Users className="w-4 h-4 mr-2 inline" />Dashboard
              </a>
              <a href="#" className="text-piano-gray-500 hover:text-gold-500 font-medium transition-colors">
                <Users className="w-4 h-4 mr-2 inline" />Estudiantes
              </a>
              <a href="#" className="text-piano-gray-500 hover:text-gold-500 font-medium transition-colors">
                <CalendarCheck className="w-4 h-4 mr-2 inline" />Horarios
              </a>
              <a href="#" className="text-piano-gray-500 hover:text-gold-500 font-medium transition-colors">
                <TrendingUp className="w-4 h-4 mr-2 inline" />Progreso
              </a>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-piano-gray-500 hover:text-gold-500">
                <Bell className="w-5 h-5" />
              </Button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gold-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                  {getInitials(authData.user.name)}
                </div>
                <span className="text-sm font-medium text-piano-black hidden sm:block">
                  {authData.user.name}
                </span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => logout.mutate()}
                  className="text-piano-gray-500 hover:text-red-500"
                >
                  Salir
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-serif font-semibold text-piano-black mb-2">
            Bienvenida, {authData.user.name}
          </h2>
          <p className="text-piano-gray-600">Aquí tienes un resumen de tus estudiantes y clases de hoy</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-gold-100 text-gold-600">
                  <Users className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-piano-gray-500">Total Estudiantes</p>
                  <p className="text-2xl font-semibold text-piano-black">{stats?.totalStudents || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-green-100 text-green-600">
                  <CalendarCheck className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-piano-gray-500">Clases Hoy</p>
                  <p className="text-2xl font-semibold text-piano-black">{stats?.todaysLessons || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-blue-100 text-blue-600">
                  <Music className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-piano-gray-500">Tareas Pendientes</p>
                  <p className="text-2xl font-semibold text-piano-black">{stats?.pendingAssignments || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-purple-100 text-purple-600">
                  <Trophy className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-piano-gray-500">Promedio General</p>
                  <p className="text-2xl font-semibold text-piano-black">{stats?.averageGrade?.toFixed(1) || '0.0'}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Students List */}
          <div className="lg:col-span-2">
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader className="border-b border-piano-gray-200">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                    Mis Estudiantes
                  </CardTitle>
                  <Button className="piano-key-btn bg-gold-500 hover:bg-gold-600 text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    Nuevo Estudiante
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {/* Search and Filter */}
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-piano-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Buscar estudiantes..."
                      className="pl-10"
                    />
                  </div>
                  <Select>
                    <SelectTrigger className="w-full sm:w-48">
                      <SelectValue placeholder="Todos los instrumentos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los instrumentos</SelectItem>
                      <SelectItem value="piano">Piano</SelectItem>
                      <SelectItem value="violin">Violín</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Students Grid */}
                <div className="space-y-4">
                  {students?.map((student, index) => (
                    <Card key={student.id} className="border border-piano-gray-200 hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className={`w-12 h-12 ${getAvatarColor(index)} rounded-full flex items-center justify-center text-white font-semibold`}>
                              {getInitials(student.user.name)}
                            </div>
                            <div>
                              <h4 className="font-semibold text-piano-black">{student.user.name}</h4>
                              <div className="flex items-center space-x-4 text-sm text-piano-gray-500">
                                <span className="flex items-center">
                                  {student.instrument === 'Piano' ? <Music className="w-3 h-3 mr-1" /> : <Piano className="w-3 h-3 mr-1" />}
                                  {student.instrument}
                                </span>
                                <span className="flex items-center">
                                  <Star className="w-3 h-3 mr-1" />
                                  {student.level}
                                </span>
                                <span className="flex items-center">
                                  <Clock className="w-3 h-3 mr-1" />
                                  {student.schedule || 'Sin horario'}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <div className="text-right">
                              <p className="text-sm font-medium text-piano-black">Progreso</p>
                              <div className="w-24 bg-piano-gray-200 rounded-full h-2 mt-1">
                                <div className={`progress-piano ${getProgressWidth(student.level)} h-2 rounded-full`}></div>
                              </div>
                            </div>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="piano-key-btn"
                              onClick={() => setLocation(`/student/${student.id}`)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {(!students || students.length === 0) && (
                    <div className="text-center py-8 text-piano-gray-500">
                      <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No hay estudiantes registrados aún</p>
                      <Button className="mt-4 piano-key-btn bg-gold-500 hover:bg-gold-600 text-white">
                        <Plus className="w-4 h-4 mr-2" />
                        Agregar primer estudiante
                      </Button>
                    </div>
                  )}
                </div>

                {students && students.length > 0 && (
                  <div className="mt-6 text-center">
                    <Button variant="secondary" className="piano-key-btn">
                      Ver todos los estudiantes
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Today's Schedule */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader className="border-b border-piano-gray-200">
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Clases de Hoy
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {todaysLessons?.map((lesson, index) => {
                    const colors = ['border-gold-500 bg-gold-50', 'border-blue-500 bg-blue-50', 'border-green-500 bg-green-50'];
                    const iconColors = ['text-gold-600', 'text-blue-600', 'text-green-600'];
                    return (
                      <div key={lesson.id} className={`flex items-center space-x-3 p-3 rounded-lg border-l-4 ${colors[index % colors.length]}`}>
                        <div className={iconColors[index % iconColors.length]}>
                          <Clock className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-piano-black">{lesson.student.user.name}</p>
                          <p className="text-sm text-piano-gray-500">
                            {new Date(lesson.date).toLocaleTimeString('es-ES', { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })} - {lesson.student.instrument}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                  
                  {(!todaysLessons || todaysLessons.length === 0) && (
                    <div className="text-center py-4 text-piano-gray-500">
                      <CalendarCheck className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No hay clases programadas para hoy</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader className="border-b border-piano-gray-200">
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Acciones Rápidas
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <Button className="piano-key-btn w-full bg-gold-500 hover:bg-gold-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Nueva Tarea
                </Button>
                <Button variant="outline" className="piano-key-btn w-full">
                  <CalendarPlus className="w-4 h-4 mr-2" />
                  Agendar Clase
                </Button>
                <Button variant="outline" className="piano-key-btn w-full">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Ver Reportes
                </Button>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader className="border-b border-piano-gray-200">
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Actividad Reciente
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm text-piano-black">Sistema iniciado</p>
                      <p className="text-xs text-piano-gray-500">Recién</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
