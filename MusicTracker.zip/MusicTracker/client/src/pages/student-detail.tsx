import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PianoLogo } from "@/components/piano-logo";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { 
  ArrowLeft,
  Calendar, 
  BookOpen, 
  TrendingUp, 
  Music, 
  Clock, 
  User,
  Mail,
  Phone,
  MapPin,
  Edit,
  Plus
} from "lucide-react";

interface StudentWithUser {
  id: string;
  instrument: string;
  level: string;
  schedule: string | null;
  notes: string | null;
  user: {
    id: string;
    name: string;
    username: string;
    email: string | null;
  };
}

export default function StudentDetail() {
  const [, params] = useRoute("/student/:id");
  const { data: authData } = useAuth();
  const [location, setLocation] = useLocation();

  const { data: student, isLoading } = useQuery<StudentWithUser>({
    queryKey: ["/api/students", params?.id],
    enabled: !!params?.id && !!authData?.user && authData.user.role === 'teacher',
  });

  if (!authData?.user || authData.user.role !== 'teacher') {
    setLocation('/login');
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-piano-gray-50 flex items-center justify-center">
        <div className="text-piano-gray-500">Cargando perfil del estudiante...</div>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="min-h-screen bg-piano-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <h3 className="text-lg font-semibold text-piano-black mb-2">Estudiante no encontrado</h3>
            <p className="text-piano-gray-500 mb-4">El estudiante que buscas no existe o no tienes permisos para verlo.</p>
            <Button onClick={() => setLocation('/teacher/dashboard')}>
              Volver al Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(word => word[0]).join('').toUpperCase().slice(0, 2);
  };

  const getProgressValue = (level: string) => {
    switch (level) {
      case 'Principiante': return 25;
      case 'Intermedio': return 60;
      case 'Avanzado': return 85;
      default: return 0;
    }
  };

  return (
    <div className="min-h-screen bg-piano-gray-50 font-sans">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-piano-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/teacher/dashboard')}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver
            </Button>
            
            <div className="flex items-center space-x-3">
              <PianoLogo />
              <div>
                <h1 className="text-xl font-serif font-semibold text-piano-black">
                  Perfil de {student.user.name}
                </h1>
                <p className="text-xs text-piano-gray-500">Gestión del estudiante</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Student Header */}
        <div className="mb-8">
          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-semibold">
                    {getInitials(student.user.name)}
                  </div>
                  <div>
                    <h2 className="text-2xl font-serif font-semibold text-piano-black mb-2">
                      {student.user.name}
                    </h2>
                    <div className="flex items-center space-x-4 text-sm text-piano-gray-500 mb-4">
                      <span className="flex items-center">
                        <Music className="w-4 h-4 mr-1" />
                        {student.instrument}
                      </span>
                      <span className="flex items-center">
                        <TrendingUp className="w-4 h-4 mr-1" />
                        {student.level}
                      </span>
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {student.schedule || 'Sin horario asignado'}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm">
                      {student.user.email && (
                        <span className="flex items-center text-piano-gray-600">
                          <Mail className="w-4 h-4 mr-1" />
                          {student.user.email}
                        </span>
                      )}
                      <span className="flex items-center text-piano-gray-600">
                        <User className="w-4 h-4 mr-1" />
                        @{student.user.username}
                      </span>
                    </div>
                  </div>
                </div>
                <Button className="piano-key-btn bg-gold-500 hover:bg-gold-600 text-white">
                  <Edit className="w-4 h-4 mr-2" />
                  Editar Perfil
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Progress Chart */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Progreso Musical
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Técnica</span>
                      <span className="text-sm text-piano-gray-500">75%</span>
                    </div>
                    <Progress value={75} className="h-3" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Lectura Musical</span>
                      <span className="text-sm text-piano-gray-500">60%</span>
                    </div>
                    <Progress value={60} className="h-3" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Ritmo</span>
                      <span className="text-sm text-piano-gray-500">80%</span>
                    </div>
                    <Progress value={80} className="h-3" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Expresión</span>
                      <span className="text-sm text-piano-gray-500">65%</span>
                    </div>
                    <Progress value={65} className="h-3" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Progreso General</span>
                      <span className="text-sm text-piano-gray-500">{getProgressValue(student.level)}%</span>
                    </div>
                    <Progress value={getProgressValue(student.level)} className="h-4 progress-piano" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Lessons */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Clases Recientes
                </CardTitle>
                <Button variant="outline" size="sm" className="piano-key-btn">
                  <Plus className="w-4 h-4 mr-2" />
                  Nueva Clase
                </Button>
              </CardHeader>
              <CardContent className="p-6">
                <div className="text-center py-8 text-piano-gray-500">
                  <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No hay clases registradas aún</p>
                  <Button className="mt-4 piano-key-btn bg-gold-500 hover:bg-gold-600 text-white" size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Programar primera clase
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Assignments */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Tareas Asignadas
                </CardTitle>
                <Button variant="outline" size="sm" className="piano-key-btn">
                  <Plus className="w-4 h-4 mr-2" />
                  Nueva Tarea
                </Button>
              </CardHeader>
              <CardContent className="p-6">
                <div className="text-center py-8 text-piano-gray-500">
                  <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No hay tareas asignadas aún</p>
                  <Button className="mt-4 piano-key-btn bg-gold-500 hover:bg-gold-600 text-white" size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Asignar primera tarea
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Student Info */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Información del Estudiante
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-piano-gray-500">Instrumento</label>
                    <p className="text-piano-black">{student.instrument}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-piano-gray-500">Nivel</label>
                    <p className="text-piano-black">{student.level}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-piano-gray-500">Horario</label>
                    <p className="text-piano-black">{student.schedule || 'No asignado'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-piano-gray-500">Email</label>
                    <p className="text-piano-black">{student.user.email || 'No registrado'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Acciones Rápidas
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <Button className="piano-key-btn w-full bg-gold-500 hover:bg-gold-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Asignar Tarea
                </Button>
                <Button variant="outline" className="piano-key-btn w-full">
                  <Calendar className="w-4 h-4 mr-2" />
                  Programar Clase
                </Button>
                <Button variant="outline" className="piano-key-btn w-full">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Registrar Progreso
                </Button>
                <Button variant="outline" className="piano-key-btn w-full">
                  <Edit className="w-4 h-4 mr-2" />
                  Agregar Notas
                </Button>
              </CardContent>
            </Card>

            {/* Notes */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Notas del Profesor
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {student.notes ? (
                  <p className="text-sm text-piano-gray-700">{student.notes}</p>
                ) : (
                  <div className="text-center py-4 text-piano-gray-500">
                    <p className="text-sm">No hay notas registradas</p>
                    <Button variant="outline" size="sm" className="mt-2 piano-key-btn">
                      <Edit className="w-4 h-4 mr-2" />
                      Agregar nota
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
