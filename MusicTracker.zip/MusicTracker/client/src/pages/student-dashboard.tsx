import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PianoLogo } from "@/components/piano-logo";
import { useAuth, useLogout } from "@/lib/auth";
import { useLocation } from "wouter";
import { 
  Calendar, 
  BookOpen, 
  TrendingUp, 
  Music, 
  Clock, 
  CheckCircle,
  AlertCircle,
  User
} from "lucide-react";

export default function StudentDashboard() {
  const { data: authData, isLoading: authLoading } = useAuth();
  const logout = useLogout();
  const [location, setLocation] = useLocation();

  if (authLoading) {
    return <div className="min-h-screen bg-piano-gray-50 flex items-center justify-center">
      <div className="text-piano-gray-500">Cargando...</div>
    </div>;
  }

  if (!authData?.user || authData.user.role !== 'student') {
    setLocation('/login');
    return null;
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(word => word[0]).join('').toUpperCase().slice(0, 2);
  };

  return (
    <div className="min-h-screen bg-piano-gray-50 font-sans">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-piano-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <PianoLogo />
              <div>
                <h1 className="text-xl font-serif font-semibold text-piano-black">Music Teacher</h1>
                <p className="text-xs text-piano-gray-500">Panel del Estudiante</p>
              </div>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-piano-black hover:text-gold-500 font-medium transition-colors">
                <User className="w-4 h-4 mr-2 inline" />Mi Progreso
              </a>
              <a href="#" className="text-piano-gray-500 hover:text-gold-500 font-medium transition-colors">
                <BookOpen className="w-4 h-4 mr-2 inline" />Tareas
              </a>
              <a href="#" className="text-piano-gray-500 hover:text-gold-500 font-medium transition-colors">
                <Calendar className="w-4 h-4 mr-2 inline" />Clases
              </a>
            </nav>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                  {getInitials(authData.user.name)}
                </div>
                <span className="text-sm font-medium text-piano-black hidden sm:block">
                  {authData.user.name}
                </span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => logout.mutate()}
                  className="text-piano-gray-500 hover:text-red-500"
                >
                  Salir
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-serif font-semibold text-piano-black mb-2">
            Hola, {authData.user.name}
          </h2>
          <p className="text-piano-gray-600">Revisa tu progreso musical y próximas actividades</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-blue-100 text-blue-600">
                  <Music className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-piano-gray-500">Mi Instrumento</p>
                  <p className="text-2xl font-semibold text-piano-black">Piano</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-green-100 text-green-600">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-piano-gray-500">Nivel Actual</p>
                  <p className="text-2xl font-semibold text-piano-black">Intermedio</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-yellow-100 text-yellow-600">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-piano-gray-500">Tareas Pendientes</p>
                  <p className="text-2xl font-semibold text-piano-black">3</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-piano border-piano-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-purple-100 text-purple-600">
                  <Calendar className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-piano-gray-500">Próxima Clase</p>
                  <p className="text-lg font-semibold text-piano-black">Mañana 4 PM</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Progress Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* Overall Progress */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Mi Progreso Musical
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Técnica</span>
                    <span className="text-sm text-piano-gray-500">75%</span>
                  </div>
                  <Progress value={75} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Lectura Musical</span>
                    <span className="text-sm text-piano-gray-500">60%</span>
                  </div>
                  <Progress value={60} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Ritmo</span>
                    <span className="text-sm text-piano-gray-500">80%</span>
                  </div>
                  <Progress value={80} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Expresión</span>
                    <span className="text-sm text-piano-gray-500">65%</span>
                  </div>
                  <Progress value={65} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Recent Assignments */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Tareas Recientes
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border border-piano-gray-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <div>
                        <h4 className="font-medium text-piano-black">Für Elise - Primer movimiento</h4>
                        <p className="text-sm text-piano-gray-500">Completada hace 2 días</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      Completada
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 border border-piano-gray-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Clock className="w-5 h-5 text-yellow-500" />
                      <div>
                        <h4 className="font-medium text-piano-black">Escalas mayores - Do, Sol, Re</h4>
                        <p className="text-sm text-piano-gray-500">Vence mañana</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                      Pendiente
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 border border-piano-gray-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <AlertCircle className="w-5 h-5 text-red-500" />
                      <div>
                        <h4 className="font-medium text-piano-black">Canon en Re - Pachelbel</h4>
                        <p className="text-sm text-piano-gray-500">Vencía ayer</p>
                      </div>
                    </div>
                    <Badge variant="destructive">
                      Atrasada
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Next Lesson */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Próxima Clase
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="text-center p-4 bg-gold-50 rounded-lg border-l-4 border-gold-500">
                    <div className="text-gold-600 mb-2">
                      <Calendar className="w-8 h-8 mx-auto" />
                    </div>
                    <div>
                      <p className="font-medium text-piano-black">Mañana</p>
                      <p className="text-sm text-piano-gray-500">4:00 PM - 5:00 PM</p>
                      <p className="text-sm text-piano-gray-500">Clase de Piano</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Acciones Rápidas
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <Button className="piano-key-btn w-full bg-blue-500 hover:bg-blue-600 text-white">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Ver Todas las Tareas
                </Button>
                <Button variant="outline" className="piano-key-btn w-full">
                  <Calendar className="w-4 h-4 mr-2" />
                  Mi Calendario
                </Button>
                <Button variant="outline" className="piano-key-btn w-full">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Historial de Progreso
                </Button>
              </CardContent>
            </Card>

            {/* Recent Feedback */}
            <Card className="shadow-piano border-piano-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-serif font-semibold text-piano-black">
                  Comentarios Recientes
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="p-4 bg-piano-gray-50 rounded-lg">
                    <p className="text-sm text-piano-black mb-2">
                      "Excelente progreso en la técnica de pedal. Continúa practicando las escalas diariamente."
                    </p>
                    <p className="text-xs text-piano-gray-500">- Maestra Patricia, hace 3 días</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
