import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PianoLogo } from "@/components/piano-logo";
import { useLogin, useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { loginSchema, type LoginRequest } from "@shared/schema";
import { Music, UserIcon, GraduationCap } from "lucide-react";

export default function Login() {
  const [location, setLocation] = useLocation();
  const { data: authData } = useAuth();
  const login = useLogin();
  const { toast } = useToast();

  // Redirect if already logged in - use useEffect to avoid state updates during render
  useEffect(() => {
    if (authData?.user) {
      if (authData.user.role === 'teacher') {
        setLocation('/teacher/dashboard');
      } else {
        setLocation('/student/dashboard');
      }
    }
  }, [authData, setLocation]);

  const form = useForm<LoginRequest>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginRequest) => {
    try {
      const result = await login.mutateAsync(data);
      toast({
        title: "Bienvenido",
        description: `Hola ${result.user.name}`,
      });
      
      if (result.user.role === 'teacher') {
        setLocation('/teacher/dashboard');
      } else {
        setLocation('/student/dashboard');
      }
    } catch (error) {
      toast({
        title: "Error de autenticación",
        description: "Usuario o contraseña incorrectos",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-piano-gray-50 to-piano-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-piano border border-piano-gray-200">
        <CardHeader className="text-center pb-4">
          <div className="flex justify-center mb-4">
            <PianoLogo size="lg" />
          </div>
          <CardTitle className="text-2xl font-serif text-piano-black">Music Teacher</CardTitle>
          <CardDescription className="text-piano-gray-500">
            Sistema de gestión musical
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="teacher" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="teacher" className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4" />
                Profesor
              </TabsTrigger>
              <TabsTrigger value="student" className="flex items-center gap-2">
                <UserIcon className="w-4 h-4" />
                Estudiante
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="teacher">
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Usuario</Label>
                  <Input
                    id="username"
                    {...form.register("username")}
                    placeholder="Ingrese su usuario"
                    className="piano-key-btn"
                  />
                  {form.formState.errors.username && (
                    <p className="text-sm text-destructive">
                      {form.formState.errors.username.message}
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña</Label>
                  <Input
                    id="password"
                    type="password"
                    {...form.register("password")}
                    placeholder="Ingrese su contraseña"
                    className="piano-key-btn"
                  />
                  {form.formState.errors.password && (
                    <p className="text-sm text-destructive">
                      {form.formState.errors.password.message}
                    </p>
                  )}
                </div>
                
                <Button
                  type="submit"
                  className="w-full piano-key-btn bg-gold-500 hover:bg-gold-600 text-white"
                  disabled={login.isPending}
                >
                  {login.isPending ? "Iniciando sesión..." : "Iniciar sesión como Profesor"}
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="student">
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username-student">Usuario</Label>
                  <Input
                    id="username-student"
                    {...form.register("username")}
                    placeholder="Ingrese su usuario"
                    className="piano-key-btn"
                  />
                  {form.formState.errors.username && (
                    <p className="text-sm text-destructive">
                      {form.formState.errors.username.message}
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password-student">Contraseña</Label>
                  <Input
                    id="password-student"
                    type="password"
                    {...form.register("password")}
                    placeholder="Ingrese su contraseña"
                    className="piano-key-btn"
                  />
                  {form.formState.errors.password && (
                    <p className="text-sm text-destructive">
                      {form.formState.errors.password.message}
                    </p>
                  )}
                </div>
                
                <Button
                  type="submit"
                  className="w-full piano-key-btn bg-blue-500 hover:bg-blue-600 text-white"
                  disabled={login.isPending}
                >
                  {login.isPending ? "Iniciando sesión..." : "Iniciar sesión como Estudiante"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
