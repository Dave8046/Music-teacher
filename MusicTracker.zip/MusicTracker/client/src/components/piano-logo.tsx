export function PianoLogo({ className = "", size = "md" }: { className?: string; size?: "sm" | "md" | "lg" }) {
  const sizeClasses = {
    sm: "w-8 h-5",
    md: "w-10 h-6", 
    lg: "w-12 h-7"
  };

  return (
    <div className={`${sizeClasses[size]} ${className}`}>
      <svg width="100%" height="100%" viewBox="0 0 40 24" className="rounded-b-md border border-gray-200">
        <defs>
          <pattern id="pianoKeys" x="0" y="0" width="40" height="24" patternUnits="userSpaceOnUse">
            {/* White keys */}
            <rect x="0" y="0" width="5.71" height="24" fill="#ffffff" stroke="#e5e7eb" strokeWidth="0.5"/>
            <rect x="5.71" y="0" width="5.71" height="24" fill="#ffffff" stroke="#e5e7eb" strokeWidth="0.5"/>
            <rect x="11.42" y="0" width="5.71" height="24" fill="#ffffff" stroke="#e5e7eb" strokeWidth="0.5"/>
            <rect x="17.13" y="0" width="5.71" height="24" fill="#ffffff" stroke="#e5e7eb" strokeWidth="0.5"/>
            <rect x="22.84" y="0" width="5.71" height="24" fill="#ffffff" stroke="#e5e7eb" strokeWidth="0.5"/>
            <rect x="28.55" y="0" width="5.71" height="24" fill="#ffffff" stroke="#e5e7eb" strokeWidth="0.5"/>
            <rect x="34.26" y="0" width="5.74" height="24" fill="#ffffff" stroke="#e5e7eb" strokeWidth="0.5"/>
            
            {/* Black keys */}
            <rect x="4.28" y="0" width="2.86" height="15" fill="#1a1a1a"/>
            <rect x="9.99" y="0" width="2.86" height="15" fill="#1a1a1a"/>
            <rect x="18.56" y="0" width="2.86" height="15" fill="#1a1a1a"/>
            <rect x="24.27" y="0" width="2.86" height="15" fill="#1a1a1a"/>
            <rect x="29.98" y="0" width="2.86" height="15" fill="#1a1a1a"/>
          </pattern>
        </defs>
        <rect width="40" height="24" fill="url(#pianoKeys)" />
      </svg>
    </div>
  );
}
