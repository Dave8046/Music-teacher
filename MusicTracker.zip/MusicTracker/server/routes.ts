import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, insertStudentSchema, insertAssignmentSchema, insertLessonSchema, insertProgressSchema } from "@shared/schema";
import { z } from "zod";

// Extend Express session interface
declare module 'express-session' {
  interface SessionData {
    userId: string;
    userRole: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      console.log("Login request body:", req.body);
      const { username, password } = loginSchema.parse(req.body);
      // Trim whitespace and remove extra characters
      const cleanUsername = username.trim().replace(/[^a-zA-Z0-9_.-]/g, '');
      const cleanPassword = password.trim();
      console.log("Parsed data:", { username: cleanUsername, password: "***" });
      const user = await storage.validateUser(cleanUsername, cleanPassword);
      
      if (!user) {
        console.log("User validation failed for:", cleanUsername);
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Store user in session
      req.session.userId = user.id;
      req.session.userRole = user.role;

      console.log("Login successful for:", cleanUsername);
      res.json({ user: { ...user, password: undefined } });
    } catch (error) {
      console.log("Login error:", error);
      res.status(400).json({ 
        message: "Invalid request data", 
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.log("Session destroy error:", err);
      }
    });
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/me", async (req, res) => {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    res.json({ user: { ...user, password: undefined } });
  });

  // Students routes
  app.get("/api/students", async (req, res) => {
    const userId = req.session?.userId;
    const userRole = req.session?.userRole;
    
    if (!userId || userRole !== 'teacher') {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const students = await storage.getStudentsByTeacher(userId);
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", async (req, res) => {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const student = await storage.getStudentById(req.params.id);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  app.post("/api/students", async (req, res) => {
    const userId = req.session?.userId;
    const userRole = req.session?.userRole;
    
    if (!userId || userRole !== 'teacher') {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const studentData = insertStudentSchema.parse({
        ...req.body,
        teacherId: userId,
      });
      const student = await storage.createStudent(studentData);
      res.json(student);
    } catch (error) {
      res.status(400).json({ message: "Invalid student data" });
    }
  });

  // Teacher dashboard stats
  app.get("/api/teacher/stats", async (req, res) => {
    const userId = req.session?.userId;
    const userRole = req.session?.userRole;
    
    if (!userId || userRole !== 'teacher') {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const stats = await storage.getTeacherStats(userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Today's lessons
  app.get("/api/lessons/today", async (req, res) => {
    const userId = req.session?.userId;
    const userRole = req.session?.userRole;
    
    if (!userId || userRole !== 'teacher') {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const lessons = await storage.getTodaysLessons(userId);
      res.json(lessons);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch today's lessons" });
    }
  });

  // Assignments routes
  app.get("/api/assignments", async (req, res) => {
    const userId = req.session?.userId;
    const userRole = req.session?.userRole;
    
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      let assignments;
      if (userRole === 'teacher') {
        assignments = await storage.getAssignmentsByTeacher(userId);
      } else {
        // For students, we need to get their student record first
        const students = await storage.getStudentsByTeacher(''); // This won't work, need to refactor
        assignments = await storage.getAssignmentsByStudent(userId);
      }
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch assignments" });
    }
  });

  app.post("/api/assignments", async (req, res) => {
    const userId = req.session?.userId;
    const userRole = req.session?.userRole;
    
    if (!userId || userRole !== 'teacher') {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const assignmentData = insertAssignmentSchema.parse({
        ...req.body,
        teacherId: userId,
      });
      const assignment = await storage.createAssignment(assignmentData);
      res.json(assignment);
    } catch (error) {
      res.status(400).json({ message: "Invalid assignment data" });
    }
  });

  // Progress routes
  app.get("/api/progress/:studentId", async (req, res) => {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const progress = await storage.getProgressByStudent(req.params.studentId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  app.post("/api/progress", async (req, res) => {
    const userId = req.session?.userId;
    const userRole = req.session?.userRole;
    
    if (!userId || userRole !== 'teacher') {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const progressData = insertProgressSchema.parse(req.body);
      const progress = await storage.createProgress(progressData);
      res.json(progress);
    } catch (error) {
      res.status(400).json({ message: "Invalid progress data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
