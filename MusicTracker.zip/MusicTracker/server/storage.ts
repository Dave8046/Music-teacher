import { 
  users, students, lessons, assignments, progress,
  type User, type InsertUser, type Student, type InsertStudent,
  type Lesson, type InsertLesson, type Assignment, type InsertAssignment,
  type Progress, type InsertProgress
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  validateUser(username: string, password: string): Promise<User | null>;
  
  // Student management
  getStudentsByTeacher(teacherId: string): Promise<(Student & { user: User })[]>;
  getStudentById(id: string): Promise<(Student & { user: User }) | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: string, updates: Partial<InsertStudent>): Promise<Student>;
  
  // Lesson management
  getLessonsByTeacher(teacherId: string): Promise<Lesson[]>;
  getLessonsByStudent(studentId: string): Promise<Lesson[]>;
  getTodaysLessons(teacherId: string): Promise<(Lesson & { student: Student & { user: User } })[]>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  updateLesson(id: string, updates: Partial<InsertLesson>): Promise<Lesson>;
  
  // Assignment management
  getAssignmentsByTeacher(teacherId: string): Promise<Assignment[]>;
  getAssignmentsByStudent(studentId: string): Promise<(Assignment & { teacher: User })[]>;
  createAssignment(assignment: InsertAssignment): Promise<Assignment>;
  updateAssignment(id: string, updates: Partial<InsertAssignment>): Promise<Assignment>;
  
  // Progress tracking
  getProgressByStudent(studentId: string): Promise<Progress[]>;
  createProgress(progress: InsertProgress): Promise<Progress>;
  
  // Dashboard stats
  getTeacherStats(teacherId: string): Promise<{
    totalStudents: number;
    todaysLessons: number;
    pendingAssignments: number;
    averageGrade: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, password: hashedPassword })
      .returning();
    return user;
  }

  async validateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async getStudentsByTeacher(teacherId: string): Promise<(Student & { user: User })[]> {
    const result = await db
      .select()
      .from(students)
      .innerJoin(users, eq(students.userId, users.id))
      .where(eq(students.teacherId, teacherId));
    
    return result.map(row => ({
      ...row.students,
      user: row.users,
    }));
  }

  async getStudentById(id: string): Promise<(Student & { user: User }) | undefined> {
    const [result] = await db
      .select()
      .from(students)
      .innerJoin(users, eq(students.userId, users.id))
      .where(eq(students.id, id));
    
    if (!result) return undefined;
    
    return {
      ...result.students,
      user: result.users,
    };
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const [newStudent] = await db
      .insert(students)
      .values(student)
      .returning();
    return newStudent;
  }

  async updateStudent(id: string, updates: Partial<InsertStudent>): Promise<Student> {
    const [updated] = await db
      .update(students)
      .set(updates)
      .where(eq(students.id, id))
      .returning();
    return updated;
  }

  async getLessonsByTeacher(teacherId: string): Promise<Lesson[]> {
    return await db
      .select()
      .from(lessons)
      .where(eq(lessons.teacherId, teacherId))
      .orderBy(desc(lessons.date));
  }

  async getLessonsByStudent(studentId: string): Promise<Lesson[]> {
    return await db
      .select()
      .from(lessons)
      .where(eq(lessons.studentId, studentId))
      .orderBy(desc(lessons.date));
  }

  async getTodaysLessons(teacherId: string): Promise<(Lesson & { student: Student & { user: User } })[]> {
    const today = new Date();
    const todayString = today.toISOString().split('T')[0]; // Get YYYY-MM-DD format

    const result = await db
      .select()
      .from(lessons)
      .innerJoin(students, eq(lessons.studentId, students.id))
      .innerJoin(users, eq(students.userId, users.id))
      .where(
        and(
          eq(lessons.teacherId, teacherId),
          sql`DATE(${lessons.date}) = ${todayString}`
        )
      );

    return result.map(row => ({
      ...row.lessons,
      student: {
        ...row.students,
        user: row.users,
      },
    }));
  }

  async createLesson(lesson: InsertLesson): Promise<Lesson> {
    const [newLesson] = await db
      .insert(lessons)
      .values(lesson)
      .returning();
    return newLesson;
  }

  async updateLesson(id: string, updates: Partial<InsertLesson>): Promise<Lesson> {
    const [updated] = await db
      .update(lessons)
      .set(updates)
      .where(eq(lessons.id, id))
      .returning();
    return updated;
  }

  async getAssignmentsByTeacher(teacherId: string): Promise<Assignment[]> {
    return await db
      .select()
      .from(assignments)
      .where(eq(assignments.teacherId, teacherId))
      .orderBy(desc(assignments.createdAt));
  }

  async getAssignmentsByStudent(studentId: string): Promise<(Assignment & { teacher: User })[]> {
    const result = await db
      .select()
      .from(assignments)
      .innerJoin(users, eq(assignments.teacherId, users.id))
      .where(eq(assignments.studentId, studentId))
      .orderBy(desc(assignments.createdAt));

    return result.map(row => ({
      ...row.assignments,
      teacher: row.users,
    }));
  }

  async createAssignment(assignment: InsertAssignment): Promise<Assignment> {
    const [newAssignment] = await db
      .insert(assignments)
      .values(assignment)
      .returning();
    return newAssignment;
  }

  async updateAssignment(id: string, updates: Partial<InsertAssignment>): Promise<Assignment> {
    const [updated] = await db
      .update(assignments)
      .set(updates)
      .where(eq(assignments.id, id))
      .returning();
    return updated;
  }

  async getProgressByStudent(studentId: string): Promise<Progress[]> {
    return await db
      .select()
      .from(progress)
      .where(eq(progress.studentId, studentId))
      .orderBy(desc(progress.recordedAt));
  }

  async createProgress(progressRecord: InsertProgress): Promise<Progress> {
    const [newProgress] = await db
      .insert(progress)
      .values(progressRecord)
      .returning();
    return newProgress;
  }

  async getTeacherStats(teacherId: string): Promise<{
    totalStudents: number;
    todaysLessons: number;
    pendingAssignments: number;
    averageGrade: number;
  }> {
    const studentsCount = await db
      .select({ count: sql`COUNT(*)` })
      .from(students)
      .where(eq(students.teacherId, teacherId));

    const todaysLessonsCount = await this.getTodaysLessons(teacherId);

    const pendingAssignmentsCount = await db
      .select({ count: sql`COUNT(*)` })
      .from(assignments)
      .where(
        and(
          eq(assignments.teacherId, teacherId),
          eq(assignments.status, 'pending')
        )
      );

    const avgGrade = await db
      .select({ avg: sql`AVG(CAST(${assignments.grade} AS DECIMAL))` })
      .from(assignments)
      .where(
        and(
          eq(assignments.teacherId, teacherId),
          sql`${assignments.grade} IS NOT NULL`
        )
      );

    return {
      totalStudents: Number(studentsCount[0]?.count || 0),
      todaysLessons: todaysLessonsCount.length,
      pendingAssignments: Number(pendingAssignmentsCount[0]?.count || 0),
      averageGrade: Number(avgGrade[0]?.avg || 0),
    };
  }
}

export const storage = new DatabaseStorage();
